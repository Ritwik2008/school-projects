import random, pygame , os ,sys,time as Time,datetime as dt
from pygame import mixer
class Color:
    pred = (255,0,0)
    white = (255,255,255)
    blue = (0,0,255)
    back = (0,0,0)
    black = (0,0,0)
    entity = (0,0,255)
sys_device = ["mouse","keyboard"]
class Sys():
    mouse = 0
    keyboard = 1
class sprites:
    pBox = "resources\imgs\pBox.png"
    eBox = "resources\imgs\eBox.png"
    img=pygame.image.load("resources\imgs\logo.png")
def musicType(name): 
    if name == "welc":return "welc-background.mp3"
    elif name == "main":return "gBack.mp3"
    else: return "welc-background.mp3"
pygame.init()
width , height = 1000, 600
mInfoAll = (pygame.display.Info().current_w,pygame.display.Info().current_h)
win = pygame.display.set_mode((width , height ) ,pygame.RESIZABLE)
pygame.display.set_caption("Don't Touch Blue")
pygame.display.set_icon(sprites.img)
FPS = 40
Boxes = []
holdTag = False
togKey1 = False
isMaxScreen = False
isFullScreen = False
endGame = False
gameOver = False
popMenu = True
eChance = 1000
SCORE = 0
pre_time = None
x_border = 40
aMusic = True
bMusic = False
px:int= 20
py:int= 20
if width/5 > 100:
    pw:int= 100
else:
    pw:int=width/5
if height/5 > 100:
    ph:int= 100
else:
    ph:int=height/5
vel:int = 8
eVel = 10
class gameFunc:
    def gameExit():
        pygame.quit()
        sys.exit()
    def randBox(): 
        h=ph
        y = random.randrange(x_border,height-h)
        if not bool(random.randint(0,eChance)):
            Boxes.append([width,y])
    def addScore():
        global SCORE,eChance,eVel
        SCORE += 1
        a = bool(random.randrange(0,10))
        if a: 
            if eChance>=150:
                eChance -= 10
        elif not a :
            if eVel<=150:
                eVel += 2
    def reset() -> None:
        global Boxes,SCORE,eChance,eVel
        Boxes,SCORE,eChance,eVel=[],0,1000,10
def welcScreen() -> None:
    global win,width,height,px,py,vel,togKey1,holdTag,popMenu,isFullScreen,music
    welcScreen.run = True
    music = musicType("welc")
    pygame.mixer.music.load(os.path.join("resources","audio",music))
    clock = pygame.time.Clock()
    pygame.mixer.music.play(-1)
    print("game by Ritwik Bali")
    while welcScreen.run:
        win.fill(Color.back)
        # wasdImg = pygame.image.load(os.path.join("resources","imgs","wsad.png"))
        # arkImg = pygame.image.load(os.path.join("resources","imgs","arr-keys.png"))
        logo = pygame.transform.scale(pygame.image.load(os.path.join("resources","imgs","logo.png")),(height/2,height/2))
        txt = pygame.font.Font("freesansbold.ttf",int(logo.get_width()/3))
        txt1,txt2=txt.render("DON'T TOUCH ",True,Color.white),txt.render("BLUE",True,Color.blue)
        txt1_x = (width-(txt1.get_width()+txt2.get_width()))/2
        _txt = pygame.font.Font("freesansbold.ttf",int(height/8))
        txt3 = _txt.render("PRESS ANY KEY TO START",True,Color.white)
        border = pygame.draw.rect(win,Color.white,pygame.Rect((width-logo.get_width())/2-height/100,((5*height/100)+txt1.get_height())-height/100,logo.get_width()+height/50,logo.get_height()+height/50))
        win.blit(logo,((width-logo.get_width())/2,(5*height/100)+txt1.get_height()))
        win.blit(txt1,(txt1_x,height/50))
        win.blit(txt2,(txt1_x+txt1.get_width(),height/50))
        win.blit(txt3,(
            (width-txt3.get_width())/2,
            ((12*height/100)+txt1.get_height()+logo.get_height())
        ))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameFunc.gameExit()
            if event.type == pygame.VIDEORESIZE:
                if not isFullScreen:
                    width,height=event.w, event.h
            if (event.type == pygame.KEYUP)and(event.key == pygame.K_F5):
                    if isFullScreen:
                        win = pygame.display.set_mode((width,height),pygame.RESIZABLE)
                        isFullScreen = False
                    if not isFullScreen:
                        win = pygame.display.set_mode(mInfoAll,pygame.FULLSCREEN)
                        isFullScreen = True
            elif event.type == pygame.KEYUP:
                welcScreen.run = False
def endScreen():
    global win,width,height,px,py,vel,togKey1,holdTag,popMenu,SCORE,Boxes,isFullScreen
    endScreen.run = True
    clock = pygame.time.Clock()
    mixer.music.stop()
    while endScreen.run:
        win.fill(Color.back)
        title = pygame.font.Font(("freesansbold.ttf"),int(height/5)).render(f"GAME OVER",True,Color.white)
        scoreDis = pygame.font.Font(("freesansbold.ttf"),int(height/8)).render(f"SCORE : {SCORE}",True,Color.white)
        subs = pygame.font.Font(("freesansbold.ttf"),int(height/12)).render(f"Press SPACE to continue and ESC to exit",True,Color.white)
        win.blit(title,((width-title.get_width())/2,(title.get_height()/2)))
        win.blit(scoreDis,((width-scoreDis.get_width())/2,(title.get_height()*1.5+scoreDis.get_height()*0.5)))
        win.blit(subs,((width-subs.get_width())/2,(((height-(title.get_height()*1.5+scoreDis.get_height()*1.5))-subs.get_height())/2)+(title.get_height()*1.5+scoreDis.get_height()*1.5)))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameFunc.gameExit()
            if event.type == pygame.VIDEORESIZE:
                if not isFullScreen:
                    width,height=event.w,event.h
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_ESCAPE: 
                    endScreen.run = False
                if event.key == pygame.K_SPACE:
                    gameFunc.reset()
                    mainGame()
                if event.key == pygame.K_F5:
                    if isFullScreen:
                        win = pygame.display.set_mode((width,height),pygame.RESIZABLE)
                        isFullScreen = False
                    if not isFullScreen:
                        win = pygame.display.set_mode(mInfoAll, pygame.FULLSCREEN)
                        isFullScreen = True
    pygame.quit()
    sys.exit()
def mainGame():
    global win,width,height,px,py,vel,togKey1,holdTag,SCORE,pre_time,Boxes,isFullScreen
    mainGame.run = True
    mainGame.pause = False
    music = musicType("main")
    pygame.mixer.music.load(os.path.join("resources","audio",music))
    clock = pygame.time.Clock()
    pygame.mixer.music.play(-1)
    while mainGame.run:
            # print(eChance,eVel)
            win.fill(Color.back)
            win.blit(pygame.transform.scale(pygame.image.load(sprites.pBox),(pw,ph)),(px,py))
            gameFunc.randBox()
            wlvar1 = 0
            boxLen = len(Boxes)
            while wlvar1<boxLen:
                entity_x,entity_y=(Boxes[wlvar1])[0],(Boxes[wlvar1])[1]
                win.blit(pygame.transform.scale(pygame.image.load(sprites.eBox),(pw,ph)),(entity_x,entity_y))
                def isCollide():
                    e_x,e_y = range(int(entity_x),int(entity_x+pw)),range(int(entity_y),int(entity_y+ph))
                    p_x,p_y = range(px,px+pw),range(py,py+ph)
                    if set(e_x).intersection(set(p_x)) == set():xCo = False
                    else:xCo = True
                    if set(e_y).intersection(set(p_y)) == set():yCo = False
                    else:yCo = True
                    if xCo and yCo:mainGame.run = False
                (Boxes[wlvar1])[0] -= eVel/10
                if (Boxes[wlvar1])[0] < -pw:Boxes.remove(Boxes[wlvar1])
                isCollide()
                boxLen = len(Boxes)
                wlvar1+=1               
            score=pygame.font.Font(("freesansbold.ttf"),int((x_border/5)*3)).render(f"SCORE : {SCORE}",True,Color.white)
            win.blit(score,((width-(score.get_width()+10)),int(x_border/5)))
            if not mainGame.pause:
                pygame.display.update()
            a_time=dt.datetime.now()
            time = int(a_time.strftime("%H%M%S"))
            if pre_time==None :
                pre_time = time
            if time>pre_time:
                if not mainGame.pause:
                    gameFunc.addScore()
                pre_time = time        
            moveDevice = sys_device[int(togKey1)]
            Key = pygame.key.get_pressed()
            Curs = pygame.mouse.get_pos()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    gameFunc.gameExit()
                if event.type == pygame.VIDEORESIZE:
                    if not isFullScreen:
                        width,height=event.w, event.h
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_TAB:
                        togKey1 = not togKey1
                    if event.key == pygame.K_F5:
                        if isFullScreen:
                            win = pygame.display.set_mode((width,height),pygame.RESIZABLE)
                            isFullScreen = False
                        if not isFullScreen:
                            win = pygame.display.set_mode(mInfoAll, pygame.FULLSCREEN)
                        isFullScreen = True
            if moveDevice==sys_device[Sys.mouse] and not mainGame.pause:
                if Curs[1]>=(height-ph):
                    py = height-ph
                elif Curs[1]<=x_border:
                    py = x_border
                else:
                    py = Curs[1]
            if moveDevice==sys_device[Sys.keyboard]:
                if (Key[pygame.K_w] or Key[pygame.K_UP]) and (py >= x_border) and not mainGame.pause:
                    py -= vel
                if (Key[pygame.K_s] or Key[pygame.K_DOWN]) and py <= (height-ph) and not mainGame.pause:
                    py += vel     
    pygame.mixer.Sound("resources\\audio\death.mp3").play()
    Time.sleep(0.2)
    endScreen()
if __name__ == "__main__":
    welcScreen()
    mainGame()