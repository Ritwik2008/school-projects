DON'T TOUCH BLUE
project by Ritwik Bali

#####################################################################################################################################################################

This is project is made by Ritwik Bali using python.
Ritwik Bali is a student of class 9D APS kirkee (2022-2023).

#IMPORTANT
Do not change the name of any of the file and even the text of this File. This will cause the program to not to find the file.
Recommended version  3.9. 5 and above. This game was made in python version 3.10.2

#Related File maintainence
The "resources" folder contains sound effects and images. The "main.py" file contain python scripts of the game.
Game can be runned manually by running teminals (powershell/command prompt) at the location of the files and entering "python main.py" or
automatically by running "run.exe".

"run.exe" also installs important module that are crucial for the program to run and it checks if someone is not copying the project.

#GAME RELATED
Avoid blue boxes to touch you. Move your character to protect it. 

#controls
you can use both mouse and keyboard to control your character.

By default... the device is set to mouse that is it will copy the mouse "y" position of the mouse.
whereas in the case of keyboard, "w" and "top arrow" key can be used to move your character upwards and "s" and "down arrow" key to move your character downwards

devices can be switched by using "tab" key. 

Author : Ritwik Bali
                                                                THANKS FOR READING  :)

#####################################################################################################################################################################